Only I did this. No partner

Name: Owen Anderson
Student ID: 300011168

This assignment is a guided design of a gradient desent algorithm that was first designed
for a single feature then expanded later for any number of features. 